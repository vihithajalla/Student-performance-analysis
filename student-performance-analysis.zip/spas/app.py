"""
app.py
Student Performance Analysis System - Streamlit Dashboard

Run:
    streamlit run app.py
"""

import os
import sys

import pandas as pd
import streamlit as st
import matplotlib.pyplot as plt
import seaborn as sns

sys.path.append(os.path.join(os.path.dirname(__file__), "src"))

from preprocessing import get_clean_dataset
from analysis import (
    student_summary, top_performers, at_risk_students,
    subject_performance, class_performance, pass_fail_stats,
    attendance_marks_correlation,
)
from model import train_models, best_model, predict_marks

DATA_PATH = os.path.join("data", "students.csv")

st.set_page_config(page_title="Student Performance Analysis", layout="wide")
sns.set_style("whitegrid")


@st.cache_data
def load_data():
    if not os.path.exists(DATA_PATH):
        st.error(
            "No dataset found at data/students.csv.\n\n"
            "Run `python src/generate_data.py` first, or replace data/students.csv "
            "with your own file using the same column structure."
        )
        st.stop()
    return get_clean_dataset(DATA_PATH)


@st.cache_resource
def load_models(df):
    return train_models(df)


df = load_data()

st.title("📊 Student Performance Analysis System")
st.caption("Data Science & Analytics — analyze trends, subject strengths/weaknesses, "
           "attendance impact, and predict outcomes.")

# ---------------- Sidebar filters ----------------
st.sidebar.header("Filters")
classes = st.sidebar.multiselect("Class", sorted(df["class"].unique()), default=sorted(df["class"].unique()))
subjects = st.sidebar.multiselect("Subject", sorted(df["subject"].unique()), default=sorted(df["subject"].unique()))

filtered = df[df["class"].isin(classes) & df["subject"].isin(subjects)]

# ---------------- Tabs ----------------
tab1, tab2, tab3, tab4, tab5 = st.tabs(
    ["Overview", "Visualizations", "Reports", "Predictive Analysis", "Raw Data"]
)

# ===== Tab 1: Overview =====
with tab1:
    col1, col2, col3, col4 = st.columns(4)
    col1.metric("Students", filtered["student_id"].nunique())
    col2.metric("Avg Marks", round(filtered["marks"].mean(), 1))
    col3.metric("Avg Attendance", f"{round(filtered['attendance_pct'].mean(), 1)}%")
    col4.metric("Attendance↔Marks Corr.", attendance_marks_correlation(filtered))

    st.subheader("🏆 Top Performers")
    st.dataframe(top_performers(filtered, n=10), use_container_width=True)

    st.subheader("⚠️ At-Risk Students")
    st.caption("Average marks below 50 or average attendance below 70%")
    st.dataframe(at_risk_students(filtered), use_container_width=True)

# ===== Tab 2: Visualizations =====
with tab2:
    c1, c2 = st.columns(2)

    with c1:
        st.subheader("Subject-wise Average Marks")
        subj_perf = subject_performance(filtered)
        fig, ax = plt.subplots()
        sns.barplot(data=subj_perf, x="subject", y="avg_marks", ax=ax, palette="Blues_d")
        ax.set_xticklabels(ax.get_xticklabels(), rotation=30, ha="right")
        st.pyplot(fig)

    with c2:
        st.subheader("Pass / Fail Ratio")
        pf = filtered["pass_fail"].value_counts()
        fig, ax = plt.subplots()
        ax.pie(pf.values, labels=pf.index, autopct="%1.1f%%", colors=["#4CAF50", "#E57373"])
        st.pyplot(fig)

    c3, c4 = st.columns(2)

    with c3:
        st.subheader("Class-wise Average Marks")
        cls_perf = class_performance(filtered)
        fig, ax = plt.subplots()
        sns.barplot(data=cls_perf, x="class", y="avg_marks", ax=ax, palette="Greens_d")
        st.pyplot(fig)

    with c4:
        st.subheader("Attendance vs Marks")
        fig, ax = plt.subplots()
        sns.scatterplot(data=filtered, x="attendance_pct", y="marks", hue="subject", ax=ax, alpha=0.7)
        st.pyplot(fig)

    st.subheader("Grade Distribution")
    fig, ax = plt.subplots(figsize=(8, 3))
    sns.countplot(data=filtered, x="grade", order=["A", "B", "C", "D", "F"], ax=ax, palette="viridis")
    st.pyplot(fig)

# ===== Tab 3: Reports =====
with tab3:
    st.subheader("Individual Student Report")
    student_ids = sorted(filtered["student_id"].unique())
    if student_ids:
        chosen = st.selectbox("Select Student ID", student_ids)
        student_df = filtered[filtered["student_id"] == chosen]
        st.write(f"**Name:** {student_df['name'].iloc[0]}  |  **Class:** {student_df['class'].iloc[0]}")
        st.dataframe(
            student_df[["subject", "marks", "assignment_score", "attendance_pct", "grade", "pass_fail"]],
            use_container_width=True,
        )
        st.metric("Overall Average", round(student_df["marks"].mean(), 1))

        csv = student_df.to_csv(index=False).encode("utf-8")
        st.download_button("⬇️ Download Student Report (CSV)", csv,
                            file_name=f"student_{chosen}_report.csv", mime="text/csv")
    else:
        st.info("No students match the current filters.")

    st.subheader("Class-wise Analytics Summary")
    st.dataframe(class_performance(filtered), use_container_width=True)

    st.subheader("Pass/Fail Statistics")
    st.dataframe(pass_fail_stats(filtered), use_container_width=True)

# ===== Tab 4: Predictive Analysis =====
with tab4:
    st.subheader("Predict Final Marks")
    st.caption("Models trained on attendance % and assignment score to predict marks.")

    with st.spinner("Training models..."):
        results = load_models(df)

    metrics_df = pd.DataFrame(
        {name: {"MAE": r["mae"], "R2": r["r2"]} for name, r in results.items()}
    ).T
    st.dataframe(metrics_df, use_container_width=True)

    best_name, model = best_model(results)
    st.success(f"Best performing model: **{best_name}**")

    col1, col2 = st.columns(2)
    attendance_input = col1.slider("Attendance (%)", 0, 100, 80)
    assignment_input = col2.slider("Assignment Score", 0, 100, 75)

    if st.button("Predict Marks"):
        prediction = predict_marks(model, attendance_input, assignment_input)
        st.metric("Predicted Marks", prediction)
        if prediction < 50:
            st.warning("⚠️ This profile suggests the student may be at risk academically.")
        else:
            st.success("✅ This profile suggests a healthy academic trajectory.")

# ===== Tab 5: Raw Data =====
with tab5:
    st.subheader("Cleaned Dataset")
    st.dataframe(filtered, use_container_width=True)
    st.caption(f"Showing {len(filtered)} of {len(df)} total rows.")
