"""
generate_data.py
Generates a synthetic but realistic student performance dataset
and saves it to data/students.csv

Run:
    python src/generate_data.py
"""

import numpy as np
import pandas as pd
import os

np.random.seed(42)

NUM_STUDENTS = 200
SUBJECTS = ["Math", "Science", "English", "Computer Science", "History"]
CLASSES = ["10-A", "10-B", "11-A", "11-B"]

def generate():
    rows = []
    for sid in range(1, NUM_STUDENTS + 1):
        name = f"Student_{sid}"
        student_class = np.random.choice(CLASSES)

        # Base ability level per student (drives correlated marks/attendance)
        ability = np.random.normal(70, 12)
        attendance = np.clip(np.random.normal(80, 10) + (ability - 70) * 0.3, 40, 100)

        for subject in SUBJECTS:
            subject_noise = np.random.normal(0, 8)
            marks = ability + subject_noise + (attendance - 80) * 0.15
            marks = float(np.clip(marks, 0, 100))

            assignment_score = float(np.clip(marks + np.random.normal(0, 5), 0, 100))

            rows.append({
                "student_id": sid,
                "name": name,
                "class": student_class,
                "subject": subject,
                "marks": round(marks, 1),
                "assignment_score": round(assignment_score, 1),
                "attendance_pct": round(attendance, 1),
                "term": "Term 1",
            })

    df = pd.DataFrame(rows)

    # Intentionally introduce a few missing values to simulate real-world data
    missing_idx = np.random.choice(df.index, size=15, replace=False)
    df.loc[missing_idx, "marks"] = np.nan

    return df


if __name__ == "__main__":
    os.makedirs("data", exist_ok=True)
    df = generate()
    out_path = os.path.join("data", "students.csv")
    df.to_csv(out_path, index=False)
    print(f"Generated {len(df)} rows -> {out_path}")
