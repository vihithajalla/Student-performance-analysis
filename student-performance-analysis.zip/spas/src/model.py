"""
model.py
Predictive analysis: train a model to predict a student's marks from
attendance and assignment score, and flag at-risk students.
"""

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, r2_score


FEATURES = ["attendance_pct", "assignment_score"]
TARGET = "marks"


def prepare_data(df: pd.DataFrame):
    X = df[FEATURES]
    y = df[TARGET]
    return train_test_split(X, y, test_size=0.2, random_state=42)


def train_models(df: pd.DataFrame):
    """Trains Linear Regression, Decision Tree, and Random Forest,
    returns a dict of {name: (model, mae, r2)} sorted by best R2."""
    X_train, X_test, y_train, y_test = prepare_data(df)

    candidates = {
        "Linear Regression": LinearRegression(),
        "Decision Tree": DecisionTreeRegressor(max_depth=5, random_state=42),
        "Random Forest": RandomForestRegressor(n_estimators=200, max_depth=6, random_state=42),
    }

    results = {}
    for name, model in candidates.items():
        model.fit(X_train, y_train)
        preds = model.predict(X_test)
        mae = mean_absolute_error(y_test, preds)
        r2 = r2_score(y_test, preds)
        results[name] = {"model": model, "mae": round(mae, 2), "r2": round(r2, 3)}

    return results


def best_model(results: dict):
    name = max(results, key=lambda k: results[k]["r2"])
    return name, results[name]["model"]


def predict_marks(model, attendance_pct: float, assignment_score: float) -> float:
    pred = model.predict([[attendance_pct, assignment_score]])[0]
    return round(float(pred), 1)


if __name__ == "__main__":
    import sys, os
    sys.path.append(os.path.dirname(__file__))
    from preprocessing import get_clean_dataset

    df = get_clean_dataset(os.path.join(os.path.dirname(__file__), "..", "data", "students.csv"))
    results = train_models(df)

    for name, r in results.items():
        print(f"{name}: MAE={r['mae']}  R2={r['r2']}")

    best_name, best = best_model(results)
    print(f"\nBest model: {best_name}")
    print("Example prediction (90% attendance, 85 assignment score):",
          predict_marks(best, 90, 85))
