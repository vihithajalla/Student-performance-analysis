"""
preprocessing.py
Data cleaning and feature engineering for the student performance dataset.
"""

import pandas as pd
import numpy as np


def load_data(path: str = "data/students.csv") -> pd.DataFrame:
    return pd.read_csv(path)


def clean_data(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()

    # Fill missing marks with the subject-wise median
    df["marks"] = df.groupby("subject")["marks"].transform(
        lambda x: x.fillna(x.median())
    )

    # Drop exact duplicate rows
    df = df.drop_duplicates()

    # Clip out-of-range values defensively
    df["marks"] = df["marks"].clip(0, 100)
    df["attendance_pct"] = df["attendance_pct"].clip(0, 100)
    df["assignment_score"] = df["assignment_score"].clip(0, 100)

    return df


def add_features(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df["pass_fail"] = np.where(df["marks"] >= 35, "Pass", "Fail")
    df["grade"] = pd.cut(
        df["marks"],
        bins=[-1, 35, 50, 65, 80, 100],
        labels=["F", "D", "C", "B", "A"],
    )
    df["attendance_bucket"] = pd.cut(
        df["attendance_pct"],
        bins=[0, 60, 75, 90, 100],
        labels=["Low (<60%)", "Medium (60-75%)", "Good (75-90%)", "Excellent (90-100%)"],
    )
    return df


def get_clean_dataset(path: str = "data/students.csv") -> pd.DataFrame:
    df = load_data(path)
    df = clean_data(df)
    df = add_features(df)
    return df


if __name__ == "__main__":
    df = get_clean_dataset()
    print(df.head())
    print(f"\nRows: {len(df)} | Missing marks remaining: {df['marks'].isna().sum()}")
