"""
analysis.py
Performance analysis functions: averages, top performers, weak subjects,
pass/fail stats, attendance-marks relationship.
"""

import pandas as pd


def student_summary(df: pd.DataFrame) -> pd.DataFrame:
    """Average marks and attendance per student."""
    return (
        df.groupby(["student_id", "name", "class"])
        .agg(avg_marks=("marks", "mean"), avg_attendance=("attendance_pct", "mean"))
        .reset_index()
        .sort_values("avg_marks", ascending=False)
    )


def top_performers(df: pd.DataFrame, n: int = 10) -> pd.DataFrame:
    return student_summary(df).head(n)


def at_risk_students(df: pd.DataFrame, marks_threshold=50, attendance_threshold=70) -> pd.DataFrame:
    summary = student_summary(df)
    return summary[
        (summary["avg_marks"] < marks_threshold)
        | (summary["avg_attendance"] < attendance_threshold)
    ].sort_values("avg_marks")


def subject_performance(df: pd.DataFrame) -> pd.DataFrame:
    return (
        df.groupby("subject")
        .agg(avg_marks=("marks", "mean"), pass_rate=("pass_fail", lambda x: (x == "Pass").mean() * 100))
        .reset_index()
        .sort_values("avg_marks", ascending=False)
    )


def class_performance(df: pd.DataFrame) -> pd.DataFrame:
    return (
        df.groupby("class")
        .agg(avg_marks=("marks", "mean"), avg_attendance=("attendance_pct", "mean"))
        .reset_index()
        .sort_values("avg_marks", ascending=False)
    )


def pass_fail_stats(df: pd.DataFrame) -> pd.DataFrame:
    counts = df["pass_fail"].value_counts(normalize=True) * 100
    return counts.round(1).reset_index().rename(columns={"index": "result", "pass_fail": "percentage"})


def attendance_marks_correlation(df: pd.DataFrame) -> float:
    return round(df["attendance_pct"].corr(df["marks"]), 3)
