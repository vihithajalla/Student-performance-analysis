# Student Performance Analysis System

A data analytics dashboard that analyzes student academic performance: trends,
subject-wise strengths/weaknesses, attendance impact on marks, pass/fail stats,
individual & class reports, and ML-based grade prediction.

## Tech Stack
- **Frontend/Dashboard:** Streamlit
- **Analytics:** Pandas, NumPy, Matplotlib, Seaborn
- **ML:** Scikit-learn (Linear Regression, Decision Tree, Random Forest)

## Project Structure
```
student-performance-analysis/
├── app.py                  # Main Streamlit dashboard
├── requirements.txt
├── data/
│   └── students.csv        # Generated dataset (created by generate_data.py)
├── src/
│   ├── generate_data.py    # Creates a synthetic sample dataset
│   ├── preprocessing.py    # Cleaning + feature engineering
│   ├── analysis.py         # Aggregations & performance metrics
│   └── model.py            # ML training & prediction
└── reports/                 # (optional) exported reports
```

## Setup (run these in order on your PC)

1. **Create and activate a virtual environment** (recommended)
   ```bash
   python -m venv venv
   # Windows
   venv\Scripts\activate
   # Mac/Linux
   source venv/bin/activate
   ```

2. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

3. **Generate the sample dataset**
   ```bash
   python src/generate_data.py
   ```
   This creates `data/students.csv` with 200 synthetic students across 5 subjects.
   To use your own data instead, replace this file — keep the same columns:
   `student_id, name, class, subject, marks, assignment_score, attendance_pct, term`.

4. **Run the dashboard**
   ```bash
   streamlit run app.py
   ```
   This opens the dashboard in your browser, typically at `http://localhost:8501`.

## Optional: test individual modules
```bash
python src/preprocessing.py   # verify cleaning works
python src/model.py           # see model comparison in terminal
```

## Dashboard Features
- **Overview** — KPIs, top performers, at-risk students
- **Visualizations** — bar/pie/line/scatter charts for subject, class, and attendance trends
- **Reports** — individual student report (downloadable CSV), class-wise summary
- **Predictive Analysis** — compares Linear Regression / Decision Tree / Random Forest, lets you predict marks from attendance + assignment score
- **Raw Data** — browse the filtered, cleaned dataset

## Next Steps / Optional Extensions
- Add login authentication (e.g., `streamlit-authenticator`)
- Add PDF report export (e.g., `fpdf2` or `reportlab`)
- Connect to MySQL/MongoDB/Firebase instead of CSV
- Deploy to Streamlit Community Cloud, Render, or Heroku
